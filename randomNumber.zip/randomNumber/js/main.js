
alert('Hawdy, Nikita.This is my first JS mini program,that I coded by myself.I would like to know "What Do U reckon?"')

document.getElementById("button").onclick = function () { random(); };

function random() {
   document.getElementById("demo").innerHTML = Math.floor(Math.random() * 100) + 1;
}
random();

/*
alert(Math.floor(Math.random() * 100) + 1);
//If u would like use this above option code pls comment the h2 and all p elements in HTML.
*/

